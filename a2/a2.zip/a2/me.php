<?php
/** I Sukhmanjeet Singh, 000838215, certify that this material is my original work. No other person's work has been used without suitable acknowledgment and I have not made my work available to anyone else. */

/**
 * @author Sukhmanjeet Singh
 * @package COMP 10260 Assignment 2
 * 
 * @version 202335.00
 */
echo "Sukhmanjeet Singh " . "000838215";
?>